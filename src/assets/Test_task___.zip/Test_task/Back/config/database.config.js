const mongoose = require("mongoose");

mongoose
  // .connect("mongodb+srv://sna773510:smt9TbRcdbeFPGuO@cluster0.olvflby.mongodb.net/book-n-watch?retryWrites=true&w=majority")
  .connect(
    "mongodb+srv://anandt607:bzTFmWWVs4uLQtq9@cluster0.x0vrg1o.mongodb.net/"
  )
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((error) => {
    console.error("Error connecting to MongoDB:", error);
  });
