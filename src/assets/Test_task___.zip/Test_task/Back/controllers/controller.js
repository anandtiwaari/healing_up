const Action = require("../models/action.model");
const SubAction = require("../models/subAction.model");
const Edges = require("../models/edges.model");

exports.saveAction = async (req, res) => {
  try {
    const { action, url, queryParams, node_id, position, label } = req.body;

    // if (!action || !url) {
    //   return res.status(400).send({ message: "Missing required fields" });
    // }

    const newAction = new Action({
      action,
      url,
      queryParams,
      node_id,
      position,
      label,
    });

    await newAction.save();
    res.status(201).send({ message: "Created Succesfully" });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};
exports.saveSubAction = async (req, res) => {
  try {
    const { action, url, queryParams, mainNodeId } = req.body;

    if (!action || !url || !queryParams || !mainNodeId) {
      return res.status(400).send({ message: "Missing required fields" });
    }

    const newSubAction = new SubAction({
      action,
      url,
      queryParams,
      mainNode: mainNodeId,
    });

    await newSubAction.save();
    res.status(201).send({ message: "SubAction created successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to save subaction" });
  }
};

exports.editAction = async (req, res) => {
  try {
    const { id } = req.params;
    const { action, url, queryParams } = req.body;

    if (!action || !url || !queryParams) {
      return res.status(400).send({ message: "Missing required fields" });
    }

    const updatedAction = await Action.findOneAndUpdate(
      { _id: id },
      { action, url, queryParams },
      { new: true }
    );

    if (!updatedAction) {
      return res.status(404).send({ message: "Action not found" });
    }

    res.status(200).send({ message: "Action updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update action" });
  }
};

exports.editSubAction = async (req, res) => {
  try {
    const { id } = req.params;
    const { action, url, queryParams } = req.body;

    if (!action || !url || !queryParams) {
      return res.status(400).send({ message: "Missing required fields" });
    }

    const updatedSubAction = await SubAction.findOneAndUpdate(
      { _id: id },
      { action, url, queryParams },
      { new: true }
    );

    if (!updatedSubAction) {
      return res.status(404).send({ message: "SubAction not found" });
    }

    res.status(200).send({
      message: "SubAction updated successfully",
      data: updatedSubAction,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update subaction" });
  }
};

exports.getActions = async (req, res) => {
  try {
    const actions = await Action.find();
    res.status(201).send({ data: actions });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};

exports.getSubActions = async (req, res) => {
  try {
    const actions = await SubAction.find();
    res.status(201).send({ data: actions });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};

exports.deleteAction = async (req, res) => {
  try {
    const { id } = req.params;
    const actions = await Action.findOneAndDelete(id);
    res.status(201).send({ data: actions });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};

exports.deleteSubAction = async (req, res) => {
  try {
    const { id } = req.params;
    const actions = await SubAction.findOneAndDelete(id);
    res.status(201).send({ data: actions });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};

exports.deleteAllData = async (req, res) => {
  try {
    const response = await Action.deleteMany({});
    const responseEdges = await Edges.deleteMany({});
    if (response) {
      return res.status(200).json({ message: "All data deleted SuccessFully" });
    }
  } catch (error) {
    console.log(error);
  }
};

exports.addEdges = async (req, res) => {
  try {
    let { id, source, target } = req.body;

    if (!id || !source || !target) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    let edges = new Edges({
      id,
      source,
      target,
    });
    let response = await edges.save();
    res
      .status(201)
      .send({ message: "Edge created successfully", data: response });
  } catch (error) {
    console.log(error);
  }
};

exports.getEdges = async (req, res) => {
  try {
    const edges = await Edges.find({});
    res.status(201).json({ data: edges });
  } catch (error) {
    res.status(500).json({ message: "Registration failed" });
  }
};
