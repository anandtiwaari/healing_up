const mongoose = require("mongoose");

const edgesSchema = new mongoose.Schema({
  id: String,
  source: String,
  target: String,
});

const Edges = mongoose.model("Edges", edgesSchema);
module.exports = Edges;
