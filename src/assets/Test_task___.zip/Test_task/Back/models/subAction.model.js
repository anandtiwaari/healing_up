const mongoose = require("mongoose");

const subActionSchema = new mongoose.Schema({
  action: String,
  url: String,
  queryParams: String,
  mainNode: { type: mongoose.Schema.Types.ObjectId, ref: "Action" },
});

const SubAction = mongoose.model("SubAction", subActionSchema);
module.exports = SubAction;
