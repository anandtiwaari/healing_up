const mongoose = require("mongoose");

const actionSchema = new mongoose.Schema({
  node_id: String,
  action: String,
  url: String,
  queryParams: String,
  position: {
    x: Number,
    y: Number,
  },
  label: String,
});

const Action = mongoose.model("Action", actionSchema);
module.exports = Action;
