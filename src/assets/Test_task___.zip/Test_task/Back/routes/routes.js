const express = require("express");
const router = express.Router();
const controller = require("../controllers/controller.js");

router.post("/save-action", controller.saveAction);
router.post("/save-sub-action", controller.saveSubAction);
router.put("/edit-action/:id", controller.editAction);
router.put("/edit-sub-action/:id", controller.editSubAction);
router.get("/get-actions", controller.getActions);
router.get("/get-sub-actions", controller.getSubActions);
router.delete("/delete-action/:id", controller.deleteAction);
router.delete("/delete-sub-action/:id", controller.deleteSubAction);
router.delete("/delete-action-all", controller.deleteAllData);
router.post("/save-edges", controller.addEdges);
router.get("/get-edges", controller.getEdges);

module.exports = router;
